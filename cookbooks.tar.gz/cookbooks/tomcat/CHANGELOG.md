## v0.10.4:

* [COOK-1110] - remove deprecated (by upstream) jpackage recipe
