## v1.1.2:

* [COOK-1076] - authorized_keys template not found in another cookbook

## v1.1.0:

* [COOK-623] - LWRP conversion
