## v1.0.4:

* [COOK-1106] - fix chkconfig loader for CentOS 5
* [COOK-1107] - use integer for GID instead of string

## v1.0.2:

* [COOK-1043] - Bluepill cookbook fails on OS X because it tries to
  use root group

## v1.0.0:

* [COOK-943] - add init script for freebsd

## v0.3.0:

* [COOK-867] - enable bluepill service on RHEL family
* [COOK-550] - add freebsd support

## v0.2.2:

* Fixes COOK-524, COOK-632
